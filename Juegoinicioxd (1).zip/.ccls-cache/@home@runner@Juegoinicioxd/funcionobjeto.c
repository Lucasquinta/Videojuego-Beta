#include <stdio.h>
#include <stdlib.h>
#include "colores.h"
#include "libreria.h"

//Creo la funcion que almacenara las otras funciones de todos los objetos del juego, con el struct y sus respectivas variables
void objetos(struct xd* x) {

    //Indico que la variable daño indica que se disminuye 1 vida por cada bala
    x->dano = 1;
    //Le doy la opcion al usuario de utilizar un objeto o no
    x->caja = rand() % 4 + 1;
    if(x->caja == 1){
      x->navaja1 = x->navaja1 + 1;
        printf(RED"Has conseguido una navaja\n"RESET);
    }
    else if(x->caja == 2){
      x->esposas1 = x->esposas1 + 1;
        printf(GREEN"Has conseguido una esposas\n"RESET);
    }
    else if(x->caja == 3){
        printf(BLUE"Has conseguido una lupa\n"RESET);
      x->lupa1 = x->lupa1 + 1;  
    }
    else if(x->caja == 4){
        printf(CYAN"Has conseguido un jugo\n"RESET);
      x->Jugo1 = x->Jugo1 + 1;  
    }
    else if(x->caja == 5){
        printf(YELLOW"Has conseguido una lata\n"RESET);
      x->lata1 = x->lata1 + 1;  
    }
    do{
        printf(CYAN"¿Quieres usar algún objeto? sí(1), no(0)\n"RESET);
        if (scanf("%d", &x->objeto) != 1 || x->objeto > 2){
                limpiarCarga();
                printf(CYAN"\nOpcion invalida, ingrese una opcion valida.\n"RESET);
            while (getchar() != '\n');
        } else {
            break;
        }
    } while (1);
    //Hago un if que indica que si el usuario presiona 1, se le mostrara una lista de objetos que puede utilizar
        if (x->objeto == 1) {
            do{
                printf(CYAN"¿Qué objeto quieres usar?\n"RESET);
                printf(CYAN"1.navaja %d. Haces 2 de daño\n"RESET, x->navaja1);
                printf(CYAN"2.esposas %d. El rival pierde un turno\n"RESET, x->esposas1);
                printf(CYAN"3.lupa %d. Puedes ver la siguiente bala\n"RESET, x->lupa1);
                printf(CYAN"4.jugo %d. Te sumas una vida\n"RESET, x->Jugo1);
                printf(CYAN"5.lata %d. Sacas la bala de la pistola\n"RESET, x->lata1);
                if (scanf("%d", &x->objeto) != 1 || x->objeto > 5){
                        limpiarCarga();
                        printf(CYAN"\nOpcion invalida, ingrese una opcion valida.\n"RESET);
                    while (getchar() != '\n');
                } else {
                    break;
                }
            } while (1);
            limpiarCarga();
        //Si el usuario presiona 1, elige la navaja
        if (x->objeto == 1) {
            if(x->navaja1 >= 1){
                x->navaja1 = x->navaja1 - 1;
            tablero(x);
            printf(GREEN"Has usado la navaja\n"RESET);
            //Llamo la funcion de la navaja
            navaja(x);
            }else{
                printf(RED"No tienes ninguna navaja\n"RESET);
            }
        } else if (x->objeto == 2) {//Si el usuario presiona 2, elige las esposas
            if(x->esposas1 >= 1){
                x->esposas1 = x->esposas1 - 1;
            printf(GREEN"Has usado las esposas\n"RESET);
            //Llamo la funcion de las esposas
            esposas(x);
            }else{
                printf(RED"No tienes esposas\n"RESET);
            }
        } else if (x->objeto == 3) {//Si el usuario presiona 3, elige la lupa
            if(x->lupa1 >= 1){
                x->lupa1 = x->lupa1 - 1;
            tablero(x);
            printf(GREEN"Has usado la lupa\n"RESET);
            //Llamo la funcion de la lupa
            lupa(x);
            }else{
                printf(RED"No tienes ninguna lupa\n"RESET);
            }
        } else if (x->objeto == 4) { //Si el usuario presiona 4, elige el jugo
            if(x->Jugo1 >= 1){
                x->Jugo1 = x->Jugo1 - 1;
            tablero(x);
            printf(GREEN"Has usado el jugo\n"RESET);
            //Llamo la funcion del jugo
            jugo(x);
            }else{
                printf(RED"No tienes ningun jugo\n"RESET);
            }
        } else if (x->objeto == 5) { //Si el usuario presiona 5, elige la lata
            if(x->lata1 >= 1){
                x->lata1 = x->lata1 - 1;
            tablero(x);
            printf(GREEN"Has usado la lata\n"RESET);
            //Llamo la funcion de la lata
            lata(x);
        
            }else{
                printf(RED"No tienes ninguna lata\n"RESET);
            }
        }else { //Si el usuario presiona un numero que no sea 1, 2, 3, 4 o 5, se le mostrara un mensaje para que ingrese una opcion valida
            printf("Opción inválida.\n");
        }
    }
    else if (x->objeto == 0){
        tablero(x);
        printf(RED"No has usado ningun objeto\n"RESET);
    }else {
        printf("Opción inválida.\n");
    }
}
