#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include "colores.h"
#include "libreria.h"

void tablero(struct xd x) {
  
  limpiar();
    printf(RED"┌────────────────────────────────────┐\n"RESET);
    printf(RED"│                 🤖                 │\n"RESET, x.cpuv);
    printf(RED"│                                    │\n"RESET);
    printf(RED"│                 🔫                 │\n"RESET);
    printf(RED"│                                    │\n"RESET);
    printf(RED"│                 🤠                 │\n"RESET, x.jugadorv);
    printf(RED"│                                    │\n"RESET);
    printf(RED"│   🪒     🔎     🔗     🧃     🥫   │\n"RESET);
    printf(RED"└────────────────────────────────────┘\n"RESET);
}