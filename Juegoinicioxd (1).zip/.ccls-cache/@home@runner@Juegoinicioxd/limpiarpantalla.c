#include <stdio.h>
#include <stdlib.h>
#include "libreria.h"
#include <unistd.h>

void limpiar() {
    usleep(2000000);
    system("clear || cls");
}

void limpiarCarga() {
    system("clear || cls");
}