#include <stdio.h>
#include <unistd.h>
#include "colores.h"
#include "libreria.h"

void Pantallacarga() {
  struct xd x;
    for (x.cargando = 0; x.cargando <= 100; x.cargando += 10) {
      printf("┌──────────────────────────────────┐\n");
      printf("│          Cargando:%3d%%           │\n", x.cargando);
      printf("│                                  │\n");
      printf("└──────────────────────────────────┘\n");
      usleep(200000); 
      limpiarCarga();
    }
}