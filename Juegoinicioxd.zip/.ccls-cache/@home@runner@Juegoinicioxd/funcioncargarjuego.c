/*
Codigo no funcionamiento
#include <stdio.h>
#include <stdlib.h>
#include "libreria.h"

void cargar_juego(struct xd x) {
  FILE *f = fopen("partidag.dat", "wb");
  if(f == NULL) { 
      perror("Error al cargar archivo\n");
      return;
  }
  //fread(x, sizeof(struct xd), 1, f);
  fclose(f);
  printf("Cargado exitoso\n");
}
*/