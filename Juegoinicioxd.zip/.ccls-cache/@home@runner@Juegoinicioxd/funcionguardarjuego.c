/*
  Codigo no funcionamiento
#include <stdio.h>
#include <stdlib.h>
#include "libreria.h"

void guardar_juego(struct xd x) {
  FILE *f = fopen("partidag.dat", "wb");
  if(f == NULL) { 
      perror("Error al guardar archivo\n");
      return;
  }
  //fwrite(x, sizeof(struct xd), 1, f);
  fclose(f);
  printf("Guardado exitoso\n");
}
*/