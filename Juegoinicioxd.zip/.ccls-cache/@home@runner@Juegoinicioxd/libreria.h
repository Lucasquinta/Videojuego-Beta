//Creo una libreria que va a almacenar todas las funciones que voy a usar en el proyecto, y ademas contenera el struct que voy a usar en el proyecto.
#ifndef LIBRERIA_H
#define LIBRERIA_H
//Creo un struct que va a almacenar los datos que voy a usar en el proyecto
struct xd{
    int bala;
    int guardarBala;
    int cpu;
    int objetocpu;
    int cpuv;//vida rival
    int jugador;
    int jugadorvi;
    int cpuvi;
    int jugadorv;//vida jugador
    int menu;
    int navaja;
    int esposas;
    int lupa;
    int Jugo;
    int lata;
    int objeto;
    int objeto2;
    int dano;
    int cargando;
    int opcion;
    int caja;
    int navaja1;
    int Jugo1;
    int lata1;
    int lupa1;
    int esposas1;
};
//Creo una funcion para las funciones del juego y la forma de jugar
void juego();
//Creo una funcion para el menu del juego
void mostrarMenu();
//Creo una funcion para los objetos del juego, que almacenara los datos de los objetos y sus funciones
void objetos();  
//Creo una funcion para la lata
void lata();
//Creo una funcion para las esposas
void esposas();
void esposasRival();
//Creo una funcion para la navaja
void navaja();
//Creo una funcion para el jugo
void jugo();
void jugoRival();
//Creo una funcion para la lupa
void lupa();
//Creo la funcion que contendra los movimientos del rival
void rival();
//Agrego la funcion que tendra la imagen
void cargarImagen();

void Pantallacarga();

void limpiarCarga();

void tablero();
/*
funciones fuera de funcionamiento
void guardar_juego(struct xd x);

void cargar_juego(struct xd x);
*/
void limpiar();
//Finalizo la libreria
#endif 